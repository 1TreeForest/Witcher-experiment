#!/firmadyne/sh
set -x
if [ "${FIRMAE_ETC}" != "true" ]; then
    exit 0
fi

${BUSYBOX} echo "WITCHER in run_service"
starting="true"
BUSYBOX=/firmadyne/busybox

if [ -f /proc/uptime ]; then
    sleeptime=$(( 90 - $(cat /proc/uptime |cut -d"." -f1) ));
    if [ "$sleeptime" -gt 0 ]; then
        echo "sleeping $sleeptime seconds"
        sleep $sleeptime;
    fi;
else
    sleep 60
fi

if [ ! -f /var/conf ]; then
    echo "Witcher attempting to create /var/conf"
    /usr/sbin/xmldbc -P /etc/services/HTTP/httpcfg.php > /var/conf || true
    echo "Witcher $(ls -la /var/conf)"
fi
if [ -f /startparty.sh ]; then
    /startparty.sh || true
fi
if [ -x /iptables-stop ]; then
    /iptables-stop &
fi

while (${BUSYBOX} true); do

    #${BUSYBOX} cat /firmadyne/service | while IFS= read -r BINARY
#for BINARY in $(cat /firmadyne/service); do
grep -v '^ *#' < /firmadyne/service | while IFS= read -r BINARY; do
    BINARY_NAME="$( basename "$(echo "${BINARY}"|cut -d" " -f1)")"
        echo "Witcher Testing for current execution of ${BINARY} using ${BINARY_NAME}"
        if ( ! ( ps | grep -v grep | grep -sqi "${BINARY_NAME}") ); then
            $BINARY > "/tmp/${BINARY_NAME}.log" 2>&1 &
            sleep 1
            if ( (${BUSYBOX} ps | ${BUSYBOX} grep -v grep | ${BUSYBOX} grep -sqi "${BINARY_NAME}") ); then
                echo "Witcher: Startup of ${BINARY_NAME} succeeded."
            else
                echo "Witcher: Startup of ${BINARY_NAME} FAILED."
            fi
        fi
    done
    IFS="${HOLD_IFS}"
    if [ "${starting}" = "true" ]; then
        ${BUSYBOX} ps
    fi
    if [ -f /startparty.sh ] && (! ps | grep -v grep | grep -sqi "3333") ; then
        /startparty.sh || true
    fi
    if [ -f /usr/sbin/infosvr ] && (! pgrep -lf "infosvr" | grep -sqi "infosvr") ; then
        /usr/sbin/infosvr lo > /tmp/infosvr.log 2>&1 &
    fi
    if [ -f /etc/rc.d/mini-upnp.sh ]; then
        if ! netstat -nul |grep ":1900"; then
            /etc/rc.d/mini-upnp.sh start
        fi
    fi
    ${BUSYBOX} sleep 10
    starting="false"

done

