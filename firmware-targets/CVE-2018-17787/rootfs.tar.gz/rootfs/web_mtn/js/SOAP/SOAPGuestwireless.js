
function SOAPGetLocalAccessSettingsResponse(){
    this.LocalAccess = "";
    this.LocalAccessTimeout = "";
};

function SOAPSetLocalAccessSettings(){
    this.LocalAccess = "";
    this.LocalAccessTimeout = "";
};

function SOAPGetWLanRadioSettingsResponse(){
    this.Enabled = "";
    this.SSID = "";
};

function SOAPGetWLanRadioSecurityResponse(){
    this.Key = "";
    this.Encryption = "";
};

function SOAPSetWLanRadioSettings(){
    this.Enabled = "";
    this.SSID = "";
    this.RadioID = "";
};

function SOAPSetWLanRadioSecurity(){
    this.Key = "";
    this.Encryption = "";
    this.RadioID = "";
};
