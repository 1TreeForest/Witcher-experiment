

function SOAPGetNetworkTomographySettingsResponse(){
    this.Address = "";
    this.Number = "";
    this.Size = "";
}


function SOAPSetNetworkTomographySettings(){
    this.Address = "";
    this.Number = "";
    this.Size = "";
}

function SOAPSetNetworkTomographyResultResponse(){
    this.PingResult = "";
}