var DebugMode=0;
var G_Language="zh-cn";

/*function detectLanguage()
{
	var sysLanguage=navigator.systemLanguage?navigator.systemLanguage:navigator.language;
	if(sysLanguage == null || sysLanguage == undefined)
	{
		G_Language="en-us";
		InitLANG("en-us");
	}
	else
	{
		var language=sysLanguage.toLowerCase();
		if(language.indexOf('zh')>-1)
		{
			G_Language="zh-cn";
			InitLANG("zh-cn");
		}
		else
		{
			G_Language="en-us";
			InitLANG("en-us");
		}
	}
	
	
	
}
detectLanguage();*/