#!/bin/sh
echo "[$0] ...." > /dev/console
# service WAN stop
service WIFI stop
# service LAN stop
event STATUS.CRITICAL
# Stop USB services
service UPNPAV stop
service ITUNES stop
service NETATALK stop
service SAMBA stop
# kill almost user space apps directly
killall -9 arpmonitor
killall -9 pppd
killall -9 proxyd
killall -9 udhcpc
killall -9 udhcpd
killall -9 igmpproxy
killall -9 portt
killall -9 upnpc
killall -9 jcpd
killall -9 udevd
killall -9 hotplugd
killall -9 fileaccessd
killall -9 stunnel
killall -9 nameresolv
killall -9 ddnsd
killall -9 dnsmasq 
killall -9 mDNSResponderPosix
killall -9 lld2d
killall -9 logd
killall -9 klogd
killall -9 updatewifistats
killall -9 hostapd
killall -9 wget
sleep 3
event HTTP.DOWN add /etc/events/FWUPDATER.sh
service HTTP stop
exit 0
