#!/bin/sh
xmldbc -k "APCLIENT_RETRY"
event SITESURVEY
service PHYINF.WIFISTA-1.1 restart
exit 0
