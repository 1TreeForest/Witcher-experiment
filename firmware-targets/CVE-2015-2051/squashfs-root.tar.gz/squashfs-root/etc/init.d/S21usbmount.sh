#!/bin/sh
mkdir -p /var/tmp/storage
