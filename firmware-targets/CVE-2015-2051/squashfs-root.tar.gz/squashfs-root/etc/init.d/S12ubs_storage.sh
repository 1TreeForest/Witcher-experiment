#!/bin/sh

insmod /lib/modules/usb-storage.ko
insmod /lib/modules/ufsd.ko
