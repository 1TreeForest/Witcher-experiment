<?
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

echo "insmod /lib/modules/emf.ko\n";
echo "insmod /lib/modules/igs.ko\n";
echo "insmod /lib/modules/dhd.ko\n";
echo "insmod /lib/modules/wl_ap.ko\n";

function startcmd($cmd)	{ echo $cmd."\n" ;}

function nvram_country_setup($wlif_bss_idx, $ccode)
{
	$ctry_code = $ccode;
	
	if ($ccode == "US" || $ccode == "NA") 
	{
		$ctry_code = "Q1";
		$regrev = 114;
	}
	//Broadcom give us CA/3 as regcode for DIR890L
	else if ($ccode == "CA") 
		$regrev = 3;
	else if ($ccode == "CN") 
		$regrev = 61;
	//Broadcom give us TW/63 as regcode for DIR890L	
	else if ($ccode == "TW")
		$regrev = 63;
	else if ($ccode == "KR")
		$regrev = 0;
	else if ($ccode == "JP")
		$regrev = 0;
	else if ($ccode == "SG")
		$regrev = 0;
	else if ($ccode == "IL")
		$regrev = 0;
	else if ($ccode == "EG")
		$regrev = 0;
	else if ($ccode == "BR" || $ccode == "AU" || $ccode == "LA")
	{
		$ctry_code = "BR";
		$regrev = 0;
	}
	else if ($ccode == "RU")
		$regrev = 5;
	else if ($ccode == "GB")
		$regrev = 0;
	else if ($ccode == "EU")
	{
		$ctry_code = "E0";
		$regrev = 46;
	}
	else
		$regrev = 0;

	startcmd("nvram set wl".$wlif_bss_idx."_country_code=".$ctry_code);
	startcmd("nvram set wl".$wlif_bss_idx."_country_rev=".$regrev);
}
$ccode = query("/runtime/devdata/countrycode");
if (isdigit($ccode)==1)
{
	TRACE_error("\n\nError\nWe do not support digital country,assign as US\n\n");	
	$ccode = "US";
}
if ($ccode == "")
{
	TRACE_error("\n\nError\nempty country,assign as US\n\n");	
	$ccode = "US";
}

//wlconf will use those country code, so we need to set it (tom, 20141031)
//initialize country code for for 5g low interface
$wlif_bss_idx = 0;
nvram_country_setup($wlif_bss_idx, $ccode);

//initialize country code for for 2.4g interface
$wlif_bss_idx = 1;
nvram_country_setup($wlif_bss_idx, $ccode);

//initialize country code for for 5g hi interface
$wlif_bss_idx = 2;
nvram_country_setup($wlif_bss_idx, $ccode);

if ($ccode == "US" || $ccode == "NA")
{
	//Broadcom give us a special power Q1/114 for DIR890L
	$ccode = "Q1/114";
}
else if ($ccode == "TW")
{
	//Broadcom give us TW/2 as regcode for DIR890L	
	$ccode = "TW/2";
}
else if ($ccode == "CA")
{
	//Broadcom give us CA/2 as regcode for DIR890L	
	$ccode = "CA/2";
}
else if ($ccode == "EU")
{
	$ccode = "E0/46";
}
else if ($ccode == "CN")
{
	$ccode = "CN/61";
}
else if ($ccode == "AU" || $ccode == "LA")
{
	$ccode = "BR";
}
else if ($ccode == "RU")
{
	$ccode = "RU/5";
}

//set smp_affinity value for performance (tom, 20121226)
//move 2.4g driver irq to CPU1
echo "echo 2 > /proc/irq/169/smp_affinity\n";
//move 5g driver irq to CPU1
echo "echo 2 > /proc/irq/163/smp_affinity\n";

/*for ap client we need set country to dirver this moment. 
  the site survey will run without wlconfig ifname up
  the driver will using default channel (1~11).
  we set the country here via wl command.
*/

startcmd("wl -i ".$BAND24G_DEVNAME." country ".$ccode);
startcmd("wl -i ".$BAND5G_DEVNAME." country ".$ccode);
startcmd("wl -i ".$BAND5G_DEVNAME2." country ".$ccode);

?>
