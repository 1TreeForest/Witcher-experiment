<? /* vi: set sw=4 ts=4: */
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w",$STOP,  "#!/bin/sh\n");

function bsd_wifi_backup($wlan)
{
	$path_tmp_bsd = "/runtime/bsd/".$wlan;		
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $wlan, 0);
	$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
	$active = query($path_phyinf_wlan."/active");
	$ssid = query($path_wlan_wifi."/ssid");
	$channel = query($path_phyinf_wlan."/media/channel");
	$encrtype = query($path_wlan_wifi."/encrtype");
	$authtype	= query($path_wlan_wifi."/authtype");
	$schedule = query($path_phyinf_wlan."/schedule");
	
	del($path_tmp_bsd);
	
	if($active != "") set($path_tmp_bsd."/active", $active);
	if($ssid != "") set($path_tmp_bsd."/ssid", $ssid);
	if($channel != "") set($path_tmp_bsd."/channel", $channel);
	if($encrtype != "") set($path_tmp_bsd."/encrtype", $encrtype);
	if($authtype != "") set($path_tmp_bsd."/authtype", $authtype);
	if($schedule != "") set($path_tmp_bsd."/schedule", $schedule);
	
	TRACE_debug("bsd_wifi_backup: wlan=".$wlan);
	TRACE_debug("bsd_wifi_backup: active=".$active);
	TRACE_debug("bsd_wifi_backup: ssid=".$ssid);	
	TRACE_debug("bsd_wifi_backup: channel=".$channel);
	TRACE_debug("bsd_wifi_backup: encrtype=".$encrtype);
	TRACE_debug("bsd_wifi_backup: authtype=".$authtype);
	
	if($encrtype != "NONE")
	{
		if($encrtype == "WEP")
		{
			$defKey = query($path_wlan_wifi."/nwkey/wep/defkey");
			$key = query($path_wlan_wifi."/nwkey/wep/key:".$defKey);
			TRACE_debug("bsd_wifi_backup: defKey=".$defKey);
			TRACE_debug("bsd_wifi_backup: key=".$key);
			if($defKey != "") set($path_tmp_bsd."/defkey", $defKey);
			if($key != "") set($path_tmp_bsd."/key", $key);
		}
		else if($authtype == "WPA+2PSK")
		{
			$key = query($path_wlan_wifi."/nwkey/psk/key");
			$passphrase = query($path_wlan_wifi."/nwkey/psk/passphrase");
			if($key != "") set($path_tmp_bsd."/key", $key);
			if($passphrase != "") set($path_tmp_bsd."/passphrase", $passphrase);
		}
	}	
}

function bsd_wificonfig_from_24g($wlan,$src)
{
	$path_24g_tmp_bsd = "/runtime/bsd/".$src;
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $wlan, 0);
	$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);	
	$24g_ssid = query($path_24g_tmp_bsd."/ssid");
	$24g_channel = query($path_24g_tmp_bsd."/channel");
	$24g_encrtype = query($path_24g_tmp_bsd."/encrtype");
	$24g_authtype	= query($path_24g_tmp_bsd."/authtype");
	$24g_schedule = query($path_24g_tmp_bsd."/schedule");
	
	TRACE_debug("bsd_wificonfig_from_24g: wlan=".$wlan);
	TRACE_debug("bsd_wificonfig_from_24g: path_24g_tmp_bsd=".$path_24g_tmp_bsd);
	TRACE_debug("bsd_wificonfig_from_24g: 24g_ssid=".$24g_ssid);
	TRACE_debug("bsd_wificonfig_from_24g: 24g_channel=".$24g_channel);
	TRACE_debug("bsd_wificonfig_from_24g: 24g_encrtype=".$24g_encrtype);
	TRACE_debug("bsd_wificonfig_from_24g: 24g_authtype=".$24g_authtype);	
	
	
	set($path_phyinf_wlan."/active", "1"); //Enable all Bands for smart connect
	if($24g_ssid != "") set($path_wlan_wifi."/ssid", $24g_ssid);
	set($path_phyinf_wlan."/media/channel", "0"); //auto channel for smart connect
	if($24g_encrtype != "") set($path_wlan_wifi."/encrtype", $24g_encrtype);
	if($24g_authtype != "") set($path_wlan_wifi."/authtype", $24g_authtype);
	
	if($24g_encrtype != "NONE")
	{
		if($24g_encrtype == "WEP")
		{
			$24g_defKey = query($path_24g_tmp_bsd."/defKey");
			$24g_key = query($path_24g_tmp_bsd."/key");
			if($24g_defKey != "") set($path_wlan_wifi."/nwkey/wep/defkey", $24g_defKey);
			if($24g_key != "") set($path_wlan_wifi."/nwkey/wep/key:".$24g_defKey, $24g_key);
		}
		else if($24g_authtype == "WPA+2PSK")
		{
			$24g_key = query($path_24g_tmp_bsd."/key");
			$24g_passphrase = query($path_24g_tmp_bsd."/passphrase");
			if($24g_key != "") set($path_wlan_wifi."/nwkey/psk/key", $24g_key);
			if($24g_passphrase != "") set($path_wlan_wifi."/nwkey/psk/passphrase", $24g_passphrase);
		}
	}	
	
	if($24g_schedule != "") set($path_phyinf_wlan."/schedule", $24g_schedule);
	else set($path_phyinf_wlan."/schedule", "");
}

function bsd_wifi_restore($wlan)
{
	$path_tmp_bsd = "/runtime/bsd/".$wlan;		
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $wlan, 0);
	$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
	$active = query($path_tmp_bsd."/active");
	$ssid = query($path_tmp_bsd."/ssid");
	$channel = query($path_tmp_bsd."/channel");
	$encrtype = query($path_tmp_bsd."/encrtype");
	$authtype	= query($path_tmp_bsd."/authtype");
	
	if($active != "") set($path_phyinf_wlan."/active", $active);
	if($ssid != "") set($path_wlan_wifi."/ssid", $ssid);
	if($channel != "") set($path_phyinf_wlan."/media/channel", $channel);
	if($encrtype != "") set($path_wlan_wifi."/encrtype", $encrtype);
	if($authtype != "") set($path_wlan_wifi."/authtype", $authtype);	
	
	if($encrtype != "NONE")
	{
		if($encrtype == "WEP")
		{
			$defKey = query($path_tmp_bsd."/defKey");
			$key = query($path_tmp_bsd."/key");
			if($defKey != "") set($path_wlan_wifi."/nwkey/wep/defkey", $defKey);
			if($key != "") set($path_wlan_wifi."/nwkey/wep/key:".$defKey, $key);
		}
		else if($authtype == "WPA+2PSK")
		{
			$key = query($path_tmp_bsd."/key");
			$passphrase = query($path_tmp_bsd."/passphrase");
			if($key != "") set($path_wlan_wifi."/nwkey/psk/key", $key);
			if($passphrase != "") set($path_wlan_wifi."/nwkey/psk/passphrase", $passphrase);
		}
	}	
}

/*
	smart connect:
		5G Lo/High Band should follow 2.4G settings(ssid, password, security)
		1. Backup original settings, restore when smart connect disable
		2. Set channel to auto channel
		3. Enable all Bands
		4. Setup smart connect nvram configs:
*/
$smart_en = query("/device/features/smartconnect");
$smart_en_gz = query("/device/features/smartconnect_gz");
if($smart_en=="1")
{
	bsd_wifi_backup($WLAN1);
	bsd_wifi_backup($WLAN2);
	bsd_wifi_backup($WLAN3);
	
	bsd_wificonfig_from_24g($WLAN1, $WLAN1);	
	bsd_wificonfig_from_24g($WLAN2, $WLAN1);
	bsd_wificonfig_from_24g($WLAN3, $WLAN1);
	
	$wlan1_bw_util = "80";
	$wlan2_bw_util = "0";	
	$wlan3_bw_util = "0";
	$wlan1_phyrate = "300";
	$wlan2_phyrate = "0";	
	$wlan3_phyrate = "400";
	$rssi = "0";	
	$wlan1_steering_flag = "0x40";
	$wlan2_steering_flag = "0x50";	
	$wlan3_steering_flag = "0x60";
	$wlan1_sta_select_flag = "0x40";
	$wlan2_sta_select_flag = "0x240";	
	$wlan3_sta_select_flag = "0x60";
	
	/*
			1. STAs are steered between 5G Low, 2.4G and 5G High RFs following below rules:
				 5G Low  --> 5G High
				 2.4G    --> 5G High
				 5G High --> 5G Low
				 5G Low STAs with phyrate less than 300Mbps are steered to 5G High
				 5G High STAs with phyrate greater than or equal to 400Mbps are steered to 5G Low
				 2.4G STAs always steered to 5G High if it's available 
			2. Do NOT check ACTIVE_STA for 2.4G STAs, but check for the other bands as usual
			3. Always check Load Balance for all bands
			4. In case of 5G Low oversubscription, BSD steers STAs to 5G High from 5G Low
				 In case of 2.4G oversubscription, BSD steers STAs to 5G High from 2.4G		
			5. If a STA connected to 2.4G, it only can steer to 5G High, and steered between 5G High/Low latter, never steered to 2.4G
	*/
	
	fwrite("a",$START,
		"nvram set bsd_role=3\n".
		"nvram set bsd_ifnames=\"".$BAND5G_DEVNAME." ".$BAND24G_DEVNAME." ".$BAND5G_DEVNAME2."\"\n".
		"nvram set bsd_scheme=2\n".
		"nvram set wl0_bsd_steering_policy=\"".$wlan1_bw_util." 5 3 ".$rssi." ".$wlan1_phyrate." ".$wlan1_steering_flag."\"\n".
		"nvram set wl1_bsd_steering_policy=\"".$wlan2_bw_util." 5 3 ".$rssi." ".$wlan2_phyrate." ".$wlan2_steering_flag."\""."\n".		
		"nvram set wl2_bsd_steering_policy=\"".$wlan3_bw_util." 5 3 ".$rssi." ".$wlan3_phyrate." ".$wlan3_steering_flag."\""."\n".
		"nvram set wl0_bsd_sta_select_policy=\"4 0 ".$wlan1_phyrate." 0 0 0 0 1 1 ".$wlan1_sta_select_flag."\"\n".
		"nvram set wl1_bsd_sta_select_policy=\"4 0 ".$wlan2_phyrate." 0 0 0 0 -1 -1 ".$wlan2_sta_select_flag."\"\n".		
		"nvram set wl2_bsd_sta_select_policy=\"4 0 ".$wlan3_phyrate." 0 0 0 0 -1 -1 ".$wlan3_sta_select_flag."\"\n".
		/* BCM bsd only allow ethX or wlX infname format for nvram bsd_if_select_policy */
		"nvram set wl0_bsd_if_select_policy=wl2\n".
		"nvram set wl1_bsd_if_select_policy=wl2\n".		
		"nvram set wl2_bsd_if_select_policy=wl0\n".
		"nvram set wl0_bsd_if_qualify_policy=\"60 0x0\"\n".
		"nvram set wl1_bsd_if_qualify_policy=\"0 0x0\"\n".		
		"nvram set wl2_bsd_if_qualify_policy=\"0 0x0\"\n".
		"nvram set bsd_bounce_detect=\"180 2 3600\"\n".
//		"nvram set bsd_msglevel=0x177\n".
		/* eapd receive BCM event packets from lan_ifnames then forward to bsd */
		"nvram set lan_ifnames=\"wl0 wl1 wl2\"\n".
		//the minimum time(3 days) before an STA can be steered back after the STA has been steered to the other band.
		"nvram set bsd_steer_timeout=259200\n".
		""
		);
	
	
	// Smart connect for Guest Zone.
	if ($smart_en_gz == 1)
	{
		bsd_wifi_backup($WLAN1_GZ);
		bsd_wifi_backup($WLAN2_GZ);
		bsd_wifi_backup($WLAN3_GZ);
		
		bsd_wificonfig_from_24g($WLAN1_GZ, $WLAN1_GZ);	
		bsd_wificonfig_from_24g($WLAN2_GZ, $WLAN1_GZ);
		bsd_wificonfig_from_24g($WLAN3_GZ, $WLAN1_GZ);
			
		fwrite("a",$START,
			/* eapd receive BCM event packets from lan_ifnames then forward to bsd */
			"nvram set lan_ifnames=\"wl0 wl1 wl2 wl0.1 wl1.1 wl2.1\"\n".

			'nvram set wifia0.1_bsd_if_select_policy=wl2.1\n'.
			'nvram set wifig0.1_bsd_if_select_policy=wl2.1\n'.
			'nvram set wifia1.1_bsd_if_select_policy=wl0.1\n'.

			'nvram set wifia0.1_bsd_steering_policy="'.$wlan1_bw_util.' 5 3 '.$rssi.' '.$wlan1_phyrate.' '.$wlan1_steering_flag.'"\n'.
			'nvram set wifig0.1_bsd_steering_policy="'.$wlan2_bw_util.' 5 3 '.$rssi.' '.$wlan2_phyrate.' '.$wlan2_steering_flag.'"\n'.
			'nvram set wifia1.1_bsd_steering_policy="'.$wlan3_bw_util.' 5 3 '.$rssi.' '.$wlan3_phyrate.' '.$wlan3_steering_flag.'"\n'.
			'nvram set wifia0.1_bsd_sta_select_policy="4 0 '.$wlan1_phyrate.' 0 0 0 0 1 1 '.$wlan1_sta_select_flag.'"\n'.
			'nvram set wifig0.1_bsd_sta_select_policy="4 0 '.$wlan2_phyrate.' 0 0 0 0 -1 -1 '.$wlan2_sta_select_flag.'"\n'.
			'nvram set wifia1.1_bsd_sta_select_policy="4 0 '.$wlan3_phyrate.' 0 0 0 0 -1 -1 '.$wlan3_sta_select_flag.'"\n'.
			'nvram set wifia0.1_bsd_if_qualify_policy="60 0x0"                           \n'.
			'nvram set wifig0.1_bsd_if_qualify_policy="0 0x0"                            \n'.
			'nvram set wifia1.1_bsd_if_qualify_policy="0 0x0"                            \n'.
			""
			);
	}
}
else if($smart_en!="1")
{
//	bsd_wifi_restore($WLAN2);	
//	bsd_wifi_restore($WLAN3);
}	
?> 
