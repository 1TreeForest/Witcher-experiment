<?
include "/htdocs/phplib/xnode.php";
include "/etc/services/PHYINF/phywifi.php";

function startcmd($cmd)      
{
	fwrite(a,$_GLOBALS["START"], $cmd."\n");
}

function try_scan_ssid_freq($uid)
{
	//force to execute sitesurvey before setting wifi_config
	
	$freq = get_phyinf_freq($uid);
	$channel = get_phyinf_channel($uid);
	if($freq == "2.4")
		return; //it has freq information, we don't need to scan ssid
	else if ($freq == "5" && $channel != "0")
		return;
    else
    {
	//do we have ssid?
    	$phy = XNODE_getpathbytarget("", "phyinf", "uid", $uid);
    	if($phy == "")
    		return 1;
    
        $wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phy."/wifi"));
    	if($wifi == "")
    		return 1;
    
    	$ssid = get("x", $wifi."/ssid");
    	
    	foreach('/runtime/wifi_tmpnode/sitesurvey/entry')
    	{
    		if(get("x", "ssid") == $ssid)
    		{
    			return 0;
    		}
    	}

    	startcmd("echo WIFI-REPEATER trigger sitesurvey > /dev/console\n");
    	startcmd('sh /etc/events/SITESURVEY.sh');
    	startcmd("sleep 10");//wait for sitesurvey
    }
	return 0;
}

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");
$wifimode=query("/device/wirelessmode");

if($wifimode=="WirelessBridge")
{
	if(is_active("WIFISTA-1.1") == 1)
	{
		if(try_scan_ssid_freq("WIFISTA-1.1")==1)
		{
			fwrite("a",$START,  "echo WIFI-REPEATER INIT FAIL > /dev/console\n");
			fwrite("a",$START,  "exit 0\n");
			fwrite("a", $STOP, "exit 0\n");
			return;
		}
	}
	fwrite("a",$START,	
		"service PHYINF.WIFISTA-1.1 start\n"
	);
      	
	fwrite("a",$STOP,
		"service PHYINF.WIFISTA-1.1 stop\n"
	);
}
else if($wifimode=="WirelessRepeaterExtender")
{
	fwrite("a",$START,	
		"service PHYINF.WIFISTA-1.1 start\n".
		"service PHYINF.WIFISTA-2.1 start\n".
		"service PHYINF.WIFISTA-1.2 start\n".
		"service PHYINF.WIFISTA-2.2 start\n".
		"service PHYINF.WIFISTA-3.1 start\n".
		"service PHYINF.WIFISTA-3.2 start\n"
	);
    		
	fwrite("a",$STOP,
		"service PHYINF.WIFISTA-3.2 stop\n".
		"service PHYINF.WIFISTA-3.1 stop\n".
		"service PHYINF.WIFISTA-2.2 stop\n".
		"service PHYINF.WIFISTA-1.2 stop\n".
		"service PHYINF.WIFISTA-2.1 stop\n".
		"service PHYINF.WIFISTA-1.1 stop\n"
	);
}

fwrite("a",$START,	"exit 0\n");
fwrite("a", $STOP,	"exit 0\n");
?>
