<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("WIFISTA-2.2");
?>
