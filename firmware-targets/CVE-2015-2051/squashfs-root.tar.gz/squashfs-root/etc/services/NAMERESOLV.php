<?

include "/etc/services/NAMERESOLV/nameresolv.php";
nameresolv_start();

?>
