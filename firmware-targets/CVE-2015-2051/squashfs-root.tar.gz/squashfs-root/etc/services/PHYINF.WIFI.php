<?
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

function startcmd($cmd)	{fwrite(a,$_GLOBALS["START"], $cmd."\n");}
function stopcmd($cmd)	{fwrite(a,$_GLOBALS["STOP"], $cmd."\n");}

function schcmd($uid)
{
	/* Get schedule setting */
	$base = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$sch = query($base."/schedule");
	if ($sch=="")	{$cmd = "start";}
	else	{$cmd = XNODE_getschedule2013cmd($sch);}
	return $cmd;
}

function setup_AP_mode()
{
	startcmd(
		"service PHYINF.BAND24G ".schcmd("BAND24G-1.1")."\n".
		"service PHYINF.BAND5G-1 ".schcmd("BAND5G-1.1")."\n".
		"service PHYINF.BAND5G-2 ".schcmd("BAND5G-2.1")."\n"
		);
	
	stopcmd(
		"service PHYINF.BAND5G-2 stop\n".
		"service PHYINF.BAND5G-1 stop\n".
		"service PHYINF.BAND24G stop\n"
		);

	/* smart connect */
	$smart_en = query("/device/features/smartconnect");
	if($smart_en=="1")
	{
		startcmd(
			"xmldbc -k SMARTCONNECT_START\n".
			"xmldbc -k EAPD_START\n".			
			"xmldbc -t \"SMARTCONNECT_START:50:bsd > /dev/console\"\n".
			"xmldbc -t \"EAPD_START:50:eapd > /dev/console\"\n"		
			);
		stopcmd(
			"killall bsd\n".
			"killall eapd\n"
			);		
	}		
}
/********************************************************************/
fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");



if(query("/device/layout")=="router")
{
    setup_AP_mode();
}
else if(query("/device/layout")=="bridge")
{
    $wirelessmode=query("/device/wirelessmode");
    if($wirelessmode=="WirelessRepeaterExtender" || $wirelessmode=="WirelessBridge")
    {
    	fwrite("a",$START,"service PHYINF.WIFI-REPEATER ".schcmd("WIFI-REPEATER")."\n");	
    	fwrite("a",$STOP,"service PHYINF.WIFI-REPEATER stop\n");	
    }
    else if($wirelessmode=="WirelessAp")
    {
        setup_AP_mode();
    }
}

fwrite("a",$START,	"exit 0\n");
fwrite("a",$STOP,	"exit 0\n");
?>
