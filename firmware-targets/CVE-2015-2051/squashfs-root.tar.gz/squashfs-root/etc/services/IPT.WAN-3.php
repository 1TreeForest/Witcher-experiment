<?
include "/htdocs/phplib/trace.php";
include "/etc/services/IPTABLES/iptwan.php";
IPTWAN_build_command("WAN-3");
?>
