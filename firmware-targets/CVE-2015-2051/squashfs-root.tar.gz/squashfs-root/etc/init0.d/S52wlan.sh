#!/bin/sh
echo [$0]: $1 ... > /dev/console

xmldbc -P /etc/services/WIFI/rtcfg.php -V ACTION="INIT" > /var/init_wifi_mod.sh

# restore txbf data from proc
if [ -f "/proc/alpha_nvram" ]; then
  TXBFUPDATE="1"
  exec < /proc/alpha_nvram
  while read line; do
    TXBFCAL=`echo $line | cut -d "=" -f1`
    TXBFVALUE=`devdata get -e $TXBFCAL`
    if [ "$TXBFVALUE" != "0" ]; then
      TXBFUPDATE="0"
      break
    fi
  done

  if [ "$TXBFUPDATE" == "1" ]; then
    exec < /proc/alpha_nvram
    while read line; do
	  devdata set -e $line
    done
  fi
fi

nvram set emf_enable=1

### 2G and 5G lower band share PCIe_0 
##2G module uses PCIe_0, port #2

nvram set devpath1=pcie/1/4
nvram set 1:devpath1=sb/1/
nvram set 1:boardrev=0x1421
nvram set 1:sromrev=11
nvram set 1:venid=0x14E4
nvram set 1:devid=0x43BB
nvram set 1:xtalfreq=40000

#nvram set 1:boardflags=0x00001000
nvram set 1:boardflags=0x20001000
nvram set 1:boardflags2=0x00000002
nvram set 1:boardflags3=0x04000005

nvram set 1:aa2g=7
nvram set 1:txchain=7
nvram set 1:rxchain=7
nvram set 1:antswitch=0

nvram set 1:temps_period=5
nvram set 1:tempthresh=120
nvram set 1:temps_hysteresis=5
nvram set 1:phycal_tempdelta=0
nvram set 1:tempoffset=0
nvram set 1:tssiposslope2g=1
nvram set 1:femctrl=3
nvram set 1:papdcap2g=0
nvram set 1:tworangetssi2g=0
nvram set 1:pdgain2g=21
nvram set 1:epagain2g=0
nvram set 1:gainctrlsph=0
nvram set 1:rxgains2gelnagaina0=4
nvram set 1:rxgains2gtrelnabypa0=1
nvram set 1:rxgains2gtrisoa0=7
nvram set 1:rxgains2gelnagaina1=4
nvram set 1:rxgains2gtrelnabypa1=1
nvram set 1:rxgains2gtrisoa1=7
nvram set 1:rxgains2gelnagaina2=4
nvram set 1:rxgains2gtrelnabypa2=1
nvram set 1:rxgains2gtrisoa2=7
nvram set 1:maxp2ga0=0x6a
nvram set 1:maxp2ga1=0x6a
nvram set 1:maxp2ga2=0x6a

nvram set 1:pa2ga0=0xff2e,0x1c46,0xfc95
nvram set 1:pa2ga1=0xff37,0x1d02,0xfc90
nvram set 1:pa2ga2=0xff2f,0x1d24,0xfc7f
nvram set 1:pdoffset2g40ma0=0
nvram set 1:pdoffset2g40ma1=0
nvram set 1:pdoffset2g40ma2=0
nvram set 1:pdoffset2g40mvalid=1

nvram set 1:cckbw202gpo=0x0000
nvram set 1:cckbw20ul2gpo=0x0000
nvram set 1:mcsbw202gpo=0xFECA6400
nvram set 1:mcsbw402gpo=0xEEEEEEEE
nvram set 1:ofdmlrbw202gpo=0x0000
nvram set 1:dot11agofdmhrbw202gpo=0x8640
#1:sb20in40lrpo=0x0000
#1:sb20in40hrpo=0x0000
#1:dot11agduplrpo=0x0000
#1:dot11agduphrpo=0x0000
nvram set 1:dot11agduplrpo=0xC0000
nvram set 1:dot11agduphrpo=0x0000

nvram set 1:agbg0=0x0
nvram set 1:agbg1=0x0
nvram set 1:agbg2=0x0

nvram set 1:rxgainerr2ga0=63
nvram set 1:rxgainerr2ga1=31
nvram set 1:rxgainerr2ga2=31

#implict txbf calibration data for 2G
nvram set 1:rpcal2g=0
TXBFCAL=`devdata get -e rpcal2g`
[ "$TXBFCAL" != "" ] && nvram set 1:rpcal2g=$TXBFCAL


##5G low band BCM43602 uses PCIe_0, port #1

nvram set devpath0=pcie/1/3
nvram set 0:devpath0=sb/1/
nvram set 0:boardrev=0x1421

nvram set 0:sromrev=11
nvram set 0:venid=0x14E4
nvram set 0:devid=0x43BC

nvram set 0:xtalfreq=40000
nvram set 0:boardflags=0x10000000
nvram set 0:boardflags2=0x00000002
nvram set 0:boardflags3=0x00000000

nvram set 0:aa5g=7

nvram set 0:txchain=7
nvram set 0:rxchain=7
nvram set 0:antswitch=0

nvram set 0:subband5gver=4

nvram set 0:temps_period=5
nvram set 0:tempthresh=120
nvram set 0:temps_hysteresis=5
nvram set 0:phycal_tempdelta=0
nvram set 0:tempoffset=0

# Set for BCM943602mcm5
nvram set 0:femctrl=6

nvram set 0:tssiposslope5g=1
nvram set 0:gainctrlsph=0
nvram set 0:papdcap5g=0
nvram set 0:tworangetssi5g=0
nvram set 0:pdgain5g=19
nvram set 0:epagain5g=0

nvram set 0:rxgains5gelnagaina0=3
nvram set 0:rxgains5gtrelnabypa0=1
nvram set 0:rxgains5gtrisoa0=6
nvram set 0:rxgains5gmelnagaina0=3
nvram set 0:rxgains5gmtrelnabypa0=1
nvram set 0:rxgains5gmtrisoa0=6
nvram set 0:rxgains5ghelnagaina0=3
nvram set 0:rxgains5ghtrelnabypa0=1
nvram set 0:rxgains5ghtrisoa0=6

nvram set 0:rxgains5gelnagaina1=3
nvram set 0:rxgains5gtrelnabypa1=1
nvram set 0:rxgains5gtrisoa1=6
nvram set 0:rxgains5gmelnagaina1=3
nvram set 0:rxgains5gmtrelnabypa1=1
nvram set 0:rxgains5gmtrisoa1=6
nvram set 0:rxgains5ghelnagaina1=3
nvram set 0:rxgains5ghtrelnabypa1=1
nvram set 0:rxgains5ghtrisoa1=6

nvram set 0:rxgains5gelnagaina2=3
nvram set 0:rxgains5gtrelnabypa2=1
nvram set 0:rxgains5gtrisoa2=6
nvram set 0:rxgains5gmelnagaina2=3
nvram set 0:rxgains5gmtrelnabypa2=1
nvram set 0:rxgains5gmtrisoa2=6
nvram set 0:rxgains5ghelnagaina2=3
nvram set 0:rxgains5ghtrelnabypa2=1
nvram set 0:rxgains5ghtrisoa2=6

nvram set 0:maxp5ga0=0x5a,0x5a,0x5a,0x5a
nvram set 0:maxp5ga1=0x5a,0x5a,0x5a,0x5a
nvram set 0:maxp5ga2=0x5a,0x5a,0x5a,0x5a

nvram set 0:pa5ga0=0xff33,0x181d,0xfd0f,0xff33,0x177f,0xfd20,0xFF33,0x1A22,0xFCD6,0xFF32,0x19FC,0xFCDD
nvram set 0:pa5ga1=0xff35,0x1757,0xfd1d,0xff30,0x174d,0xfd31,0xFF2F,0x19B3,0xFCE2,0xFF2E,0x19EB,0xFCDA
nvram set 0:pa5ga2=0xff3a,0x17d2,0xfd21,0xff28,0x1692,0xfd2f,0xFF31,0x1A12,0xFCD7,0xFF31,0x19FE,0xFCDD

nvram set 0:pdoffset40ma0=0x0044
nvram set 0:pdoffset40ma1=0x0044
nvram set 0:pdoffset40ma2=0x0044
nvram set 0:pdoffset80ma0=0x0011
nvram set 0:pdoffset80ma1=0x0011
nvram set 0:pdoffset80ma2=0x0011

nvram set 0:mcsbw205glpo=0xeecc7530
nvram set 0:mcsbw205gmpo=0xeecc7530
nvram set 0:mcsbw205ghpo=0xeecc7530
nvram set 0:mcsbw405glpo=0xfeca7531
nvram set 0:mcsbw405gmpo=0xfeca7531
nvram set 0:mcsbw405ghpo=0xfeca7531
nvram set 0:mcsbw805glpo=0xfeccccbb
nvram set 0:mcsbw805gmpo=0xfeccccbb
nvram set 0:mcsbw805ghpo=0xfeccccbb

nvram set 0:mcslr5glpo=0x0000
nvram set 0:mcslr5gmpo=0x0000
nvram set 0:mcslr5ghpo=0x0000
nvram set 0:sb20in40lrpo=0x0000
nvram set 0:sb20in40hrpo=0x0000

nvram set 0:sb20in80and160lr5glpo=0x0000
nvram set 0:sb20in80and160lr5gmpo=0x0000
nvram set 0:sb20in80and160lr5ghpo=0x0000
nvram set 0:sb20in80and160hr5glpo=0x0000
nvram set 0:sb20in80and160hr5gmpo=0x0000
nvram set 0:sb20in80and160hr5ghpo=0x0000
nvram set 0:sb40and80lr5glpo=0x0000
nvram set 0:sb40and80lr5gmpo=0x0000
nvram set 0:sb40and80lr5ghpo=0x0000
nvram set 0:sb40and80hr5glpo=0x0000
nvram set 0:sb40and80hr5gmpo=0x0000
nvram set 0:sb40and80hr5ghpo=0x0000
nvram set 0:dot11agduplrpo=0x4444
nvram set 0:dot11agduphrpo=0x4444

nvram set 0:rxgainerr5ga0=63,63,63,63
nvram set 0:rxgainerr5ga1=31,31,31,31
nvram set 0:rxgainerr5ga2=31,31,31,31

nvram set 0:aga0=0
nvram set 0:aga1=0
nvram set 0:aga2=0
nvram set 0:rpcal5gb0=0
nvram set 0:rpcal5gb1=0
nvram set 0:rpcal5gb2=0
nvram set 0:rpcal5gb3=0

#implict txbf calibration data for 5G low band
TXBFCAL=`devdata get -e rpcal5gb0`
[ "$TXBFCAL" != "" ] && nvram set 0:rpcal5gb0=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5gb1`
[ "$TXBFCAL" != "" ] && nvram set 0:rpcal5gb1=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5gb2`
[ "$TXBFCAL" != "" ] && nvram set 0:rpcal5gb2=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5gb3`
[ "$TXBFCAL" != "" ] && nvram set 0:rpcal5gb3=$TXBFCAL


##5G high band BCM43602 use PCIe_1

nvram set devpath2=pcie/2/1

nvram set 2:devpath2=sb/1/
nvram set 2:boardrev=0x1421

nvram set 2:sromrev=11
nvram set 2:venid=0x14E4

nvram set 2:devid=0x43BC

nvram set 2:xtalfreq=40000

nvram set 2:boardflags=0x30000000
nvram set 2:boardflags2=0x00200002
nvram set 2:boardflags3=0x00000006

nvram set 2:aa5g=7
nvram set 2:txchain=7
nvram set 2:rxchain=7
nvram set 2:antswitch=0
nvram set 2:subband5gver=4

# Some PAs (Anadigics, Skyworks, others) need a switched reference voltage instead of a digital control signal
# to turn the PA on. (SiGe PAs typically use a plain digital control signal). The "parefledvoltage" parameter
# is needed to set this PA reference voltage. Equation: Vout = 2.5 + param*.01  Range is 2.5V (0) to 3.1V (60).
# NOTE: Must set either bit 20 or 21 (or both) of boardflags2 to enable this parameter.
# Set the PA reference LDO voltage for 2.85V.
nvram set 2:parefldovoltage=35

nvram set 2:temps_period=5
nvram set 2:tempthresh=120
nvram set 2:temps_hysteresis=5
nvram set 2:phycal_tempdelta=0
nvram set 2:tempoffset=0
nvram set 2:femctrl=3
nvram set 2:tssiposslope5g=1
nvram set 2:gainctrlsph=0
nvram set 2:papdcap5g=0
nvram set 2:tworangetssi5g=0
nvram set 2:pdgain5g=4
nvram set 2:epagain5g=0

nvram set 2:rxgains5gelnagaina0=1
nvram set 2:rxgains5gtrelnabypa0=1
nvram set 2:rxgains5gtrisoa0=7
nvram set 2:rxgains5gmelnagaina0=2
nvram set 2:rxgains5gmtrelnabypa0=1
nvram set 2:rxgains5gmtrisoa0=5
nvram set 2:rxgains5ghelnagaina0=2
nvram set 2:rxgains5ghtrelnabypa0=1
nvram set 2:rxgains5ghtrisoa0=5
nvram set 2:rxgains5gelnagaina1=1
nvram set 2:rxgains5gtrelnabypa1=1
nvram set 2:rxgains5gtrisoa1=6
nvram set 2:rxgains5gmelnagaina1=2
nvram set 2:rxgains5gmtrelnabypa1=1
nvram set 2:rxgains5gmtrisoa1=4
nvram set 2:rxgains5ghelnagaina1=2
nvram set 2:rxgains5ghtrelnabypa1=1
nvram set 2:rxgains5ghtrisoa1=4
nvram set 2:rxgains5gelnagaina2=1
nvram set 2:rxgains5gtrelnabypa2=1
nvram set 2:rxgains5gtrisoa2=5
nvram set 2:rxgains5gmelnagaina2=3
nvram set 2:rxgains5gmtrelnabypa2=1
nvram set 2:rxgains5gmtrisoa2=4
nvram set 2:rxgains5ghelnagaina2=3
nvram set 2:rxgains5ghtrelnabypa2=1
nvram set 2:rxgains5ghtrisoa2=4

nvram set 2:maxp5ga0=0x6a,0x6a,0x6a,0x6a
nvram set 2:maxp5ga1=0x6a,0x6a,0x6a,0x6a
nvram set 2:maxp5ga2=0x6a,0x6a,0x6a,0x6a

nvram set 2:pa5ga0=0xFF1E,0x1679,0xFD31,0xFF38,0x1A7F,0xFCC3,0xff5a,0x1b4b,0xfccf,0xff38,0x1b69,0xfcac
nvram set 2:pa5ga1=0xFF1B,0x15EE,0xFD3F,0xFF38,0x1A37,0xFCCD,0xff3c,0x1a7c,0xfcb8,0xff48,0x1b6a,0xfcbd
nvram set 2:pa5ga2=0xFF1D,0x1653,0xFD33,0xFF38,0x1A2A,0xFCCE,0xff3e,0x1b69,0xfcb3,0xff3e,0x1bac,0xfca8

nvram set 2:pdoffset40ma0=0x0000
nvram set 2:pdoffset40ma1=0x0000
nvram set 2:pdoffset40ma2=0x0000
nvram set 2:pdoffset80ma0=0x0000
nvram set 2:pdoffset80ma1=0x0000
nvram set 2:pdoffset80ma2=0x0000

nvram set 2:mcsbw205glpo=0xeca86400
nvram set 2:mcsbw205gmpo=0xeca86400
nvram set 2:mcsbw205ghpo=0xeca86400
nvram set 2:mcsbw405glpo=0xeca86422
nvram set 2:mcsbw405gmpo=0xeca86422
nvram set 2:mcsbw405ghpo=0xeca86422
nvram set 2:mcsbw805glpo=0xfeca8533
nvram set 2:mcsbw805gmpo=0xfeca8533
nvram set 2:mcsbw805ghpo=0xfeca8533

nvram set 2:mcslr5glpo=0x0000
nvram set 2:mcslr5gmpo=0x0000
nvram set 2:mcslr5ghpo=0x0000

nvram set 2:sb20in40lrpo=0x0000
nvram set 2:sb20in40hrpo=0x0000
nvram set 2:sb20in80and160lr5glpo=0x0000
nvram set 2:sb20in80and160lr5gmpo=0x0000
nvram set 2:sb20in80and160lr5ghpo=0x0000
nvram set 2:sb20in80and160hr5glpo=0x0000
nvram set 2:sb20in80and160hr5gmpo=0x0000
nvram set 2:sb20in80and160hr5ghpo=0x0000
nvram set 2:sb40and80lr5glpo=0x0000
nvram set 2:sb40and80lr5gmpo=0x0000
nvram set 2:sb40and80lr5ghpo=0x0000
nvram set 2:sb40and80hr5glpo=0x0000
nvram set 2:sb40and80hr5gmpo=0x0000
nvram set 2:sb40and80hr5ghpo=0x0000
nvram set 2:dot11agduplrpo=0x0000
nvram set 2:dot11agduphrpo=0x0000

nvram set 2:rxgainerr5ga0=63,63,63,63
nvram set 2:rxgainerr5ga1=31,31,31,31
nvram set 2:rxgainerr5ga2=31,31,31,31

nvram set 2:aga0=0
nvram set 2:aga1=0
nvram set 2:aga2=0
nvram set 2:rpcal5gb0=0
nvram set 2:rpcal5gb1=0
nvram set 2:rpcal5gb2=0
nvram set 2:rpcal5gb3=0

#implict txbf calibration data for 5G high band
TXBFCAL=`devdata get -e rpcal5g2b0`
[ "$TXBFCAL" != "" ] && nvram set 2:rpcal5gb0=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5g2b1`
[ "$TXBFCAL" != "" ] && nvram set 2:rpcal5gb1=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5g2b2`
[ "$TXBFCAL" != "" ] && nvram set 2:rpcal5gb2=$TXBFCAL
TXBFCAL=`devdata get -e rpcal5g2b3`
[ "$TXBFCAL" != "" ] && nvram set 2:rpcal5gb3=$TXBFCAL

#we only insert wifi modules in init. 
xmldbc -P /etc/services/WIFI/init_wifi_mod.php >> /var/init_wifi_mod.sh
chmod +x /var/init_wifi_mod.sh
/bin/sh /var/init_wifi_mod.sh

#initial wifi interfaces
service PHYINF.WIFI restart
#workaroud for wifi security issue
xmldbc -t "PHYINF.WIFI:5:service PHYINF.WIFI restart"
