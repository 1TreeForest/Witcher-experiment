#!/bin/sh
ln -s -f /var/tmp/storage /var/portal_share
