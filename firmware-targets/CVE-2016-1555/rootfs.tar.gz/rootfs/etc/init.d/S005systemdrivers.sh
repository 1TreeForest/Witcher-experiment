${PANEL_LED} ${LED_BOOTING_MODE}
/usr/bin/watchdog &
