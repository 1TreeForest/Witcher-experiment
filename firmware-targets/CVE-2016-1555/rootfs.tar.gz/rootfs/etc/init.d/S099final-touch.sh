#!/bin/sh

${PANEL_LED} ${LED_LOGIN_MODE}
/usr/bin/reset_detect &
/usr/local/bin/update_rfStatus &
