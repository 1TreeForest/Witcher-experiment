<?php /* Smarty version 2.6.18, created on 2009-02-17 11:52:19
         compiled from Documentation.tpl */ ?>
	<tr>
		<td>
			<table class="tableStyle">
				<tr>
					<td colspan="3">
						<table class='tableStyle'>
							<tr>
								<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Documentation</td>
								<td class='subSectionTabTopRight spacer40Percent'>&nbsp;</td>
							</tr>
							<tr>
								<td colspan='3' class='subSectionTabTopShadow'></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody">
						<table class="tableStyle">
							<tr>
								<td class="font10Bold padding4Top" style="text-align: left;"><a href="<?php echo $this->_tpl_vars['DocumentationLink']; ?>
" target="_blank">Click here to open product documentation in a new window</td>
							</tr>
						</table>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom"></td>
				</tr>
			</table>
		</td>
	</tr>