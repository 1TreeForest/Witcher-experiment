#!/firmadyne/sh
set +e

BUSYBOX=/firmadyne/busybox
echo "[*] WITCHER in preInit.sh"

[ -d /dev ] || mkdir -p /dev
[ -d /root ] || mkdir -p /root
[ -d /sys ] || mkdir -p /sys
[ -d /proc ] || mkdir -p /proc
[ -d /tmp ] || mkdir -p /tmp
mkdir -p /var/lock
mkdir -p /dev/pts

${BUSYBOX} mount -t sysfs sysfs /sys || echo "Failed to mount /sys"
${BUSYBOX} mount -t proc proc /proc  || echo "Failed to mount /proc"
${BUSYBOX} ln -sf /proc/mounts /etc/mtab || echo "Failed to create symlink to /proc/mounts"


${BUSYBOX} mount -t devpts devpts /dev/pts || echo "Failed to mount /dev/pts"
${BUSYBOX} mount -t tmpfs tmpfs /run || echo "Failed to mount /run"

echo "Completed WITCHER preInit..."
