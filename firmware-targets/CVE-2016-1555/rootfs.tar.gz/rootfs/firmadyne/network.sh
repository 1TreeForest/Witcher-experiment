#!/firmadyne/sh

BUSYBOX=/firmadyne/busybox
ACTION=`${BUSYBOX} cat /firmadyne/network_type`
echo "[*] Attempting to bring up network using ${ACTION} FIRMAE_NETWORK=${FIRMAE_NETWORK}"
if (${FIRMAE_NETWORK}); then
  sleep 3

  if [ ${ACTION} == "default" ]; then


    ${BUSYBOX} brctl addbr br0
    ${BUSYBOX} ifconfig br0 192.168.0.1
    ${BUSYBOX} brctl addif br0 eth0
    ${BUSYBOX} ifconfig eth0 0.0.0.0 up

  elif [ ${ACTION} != "None" ]; then
    NET_BRIDGE=`${BUSYBOX} cat /firmadyne/net_bridge`
    NET_INTERFACE=`${BUSYBOX} cat /firmadyne/net_interface`

    # netgear WNR2000 bridge command
    while (true); do
      sleep 5
      if (${BUSYBOX} brctl show | ${BUSYBOX} grep -sq ${NET_BRIDGE}); then
        break
      fi
    done

    sleep 5

    if [ ${ACTION} == "normal" ]; then
      IP=$(${BUSYBOX} ip addr show ${NET_BRIDGE} | ${BUSYBOX} grep -m1 "inet\b" | ${BUSYBOX} awk '{print $2}' | ${BUSYBOX} cut -d/ -f1)
      # tplink TL-WA860RE_EU_UK_US__V5_171116
      ${BUSYBOX} ifconfig ${NET_BRIDGE} ${IP}
      ${BUSYBOX} ifconfig ${NET_INTERFACE} 0.0.0.0 up
    elif [ ${ACTION} == "reload" ]; then
      ${BUSYBOX} ifconfig ${NET_BRIDGE} 192.168.0.1
      ${BUSYBOX} ifconfig ${NET_INTERFACE} 0.0.0.0 up
    elif [ ${ACTION} == "bridge" ]; then
      # unexpected intercept by another bridge
      # netgear WNR2000v5-V1.0.0.34
      # dlink DIR-505L_FIRMWARE_1.01.ZIP
      # tplink TL-WA850RE_V5_180228.zip
      if (${BUSYBOX} brctl show | ${BUSYBOX} grep "eth0"); then
        WAN_BRIDGE=$(${BUSYBOX} brctl show | ${BUSYBOX} grep "eth0" | ${BUSYBOX} awk '{print $1}')
        ${BUSYBOX} brctl delif ${WAN_BRIDGE} eth0
      fi
      IP=$(${BUSYBOX} ip addr show ${NET_BRIDGE} | ${BUSYBOX} grep -m1 "inet\b" | ${BUSYBOX} awk '{print $2}' | ${BUSYBOX} cut -d/ -f1)
      ${BUSYBOX} ifconfig ${NET_BRIDGE} ${IP}
      ${BUSYBOX} brctl addif ${NET_BRIDGE} eth0
      ${BUSYBOX} ifconfig ${NET_INTERFACE} 0.0.0.0 up
    elif [ ${ACTION} == "bridgereload" ]; then
      if (${BUSYBOX} brctl show | ${BUSYBOX} grep "eth0"); then
        WAN_BRIDGE=$(${BUSYBOX} brctl show | ${BUSYBOX} grep "eth0" | ${BUSYBOX} awk '{print $1}')
        ${BUSYBOX} brctl delif ${WAN_BRIDGE} eth0
      fi
      ${BUSYBOX} ifconfig ${NET_BRIDGE} 192.168.0.1
      ${BUSYBOX} brctl addif ${NET_BRIDGE} eth0
      ${BUSYBOX} ifconfig ${NET_INTERFACE} 0.0.0.0 up
    fi
  fi
  sleep 5
  # default route for connect backs and more

  ip route add 172.0.0.0/8 via $(ifconfig $(cat /firmadyne/net_bridge) | grep "inet addr" |cut -d ":" -f2|cut -d "." -f1-3).2
  ip route add 224.0.0.0/4 dev "$(cat /firmadyne/net_bridge)" || true
  sleep 1
  ip addr show
  if ip addr show dev "$(cat /firmadyne/net_bridge)"|head -1 |grep "state UP"; then
      echo "[*] Witcher - Bridged Network is UP"
  fi
  if ip addr show dev "$(cat /firmadyne/net_interface)"|head -1 |grep "state UP"; then
      echo "[*] Witcher - Local Network Interface is UP"
  fi
  sleep 35

  # netgear TL-WR841HP_V2_151124
  while (true); do
    if ${BUSYBOX} which iptables; then
      iptables flush | true
      iptables -F | true
      iptables -P INPUT ACCEPT | true
    fi
    # cisco RVM, changes br0 ip during bootup
    if [ "$(cat /firmadyne/network_type)" == "default" ] && ! ip addr show dev "$(cat /firmadyne/net_bridge)"|grep "192.168.0.1"; then
        echo "[*] Changing ip address to default "
        ifconfig br0 192.168.0.1 netmask 255.255.255.0
    fi
    sleep 10
  done
fi
